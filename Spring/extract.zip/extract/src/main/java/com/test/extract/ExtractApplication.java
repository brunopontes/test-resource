package com.test.extract;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExtractApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExtractApplication.class, args);
	}

}
